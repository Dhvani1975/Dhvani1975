FRESHCART - ONLINE GROCERY SHOPPING WEBSITE
=============================================

Frontend-only college project.

TECHNOLOGIES:
- HTML5
- CSS3
- JavaScript
- Bootstrap 5
- Bootstrap Icons
- LocalStorage for demo cart state only

PAGES:
1. index.html       - Home
2. products.html    - Products, search and category filter
3. categories.html  - Grocery categories
4. cart.html        - Shopping cart and demo checkout
5. about.html       - About project
6. contact.html     - Contact form demo

HOW TO RUN:
1. Extract the ZIP file.
2. Open index.html in Chrome/Edge/Firefox.
3. Internet connection is recommended because Bootstrap and product images use CDN/online image URLs.

IMPORTANT:
This is ONLY frontend work.
There is NO PHP, MySQL, backend, server, real login, or real payment gateway.
The cart uses browser LocalStorage only for demonstration.

FreshCart Grocery Store - Admin Side Frontend

Open index.html in a browser. Internet connection is needed to load Bootstrap and Bootstrap Icons from CDN.

Includes Dashboard, Products, Categories, Orders, Customers, Payments, Feedback and Settings.
Add, edit, delete and search records. Demo data persists in browser localStorage. Settings include a reset button.

Built with HTML, CSS, JavaScript and Bootstrap 5. No backend, database, login authentication or real payment processing is included. Demo only.
